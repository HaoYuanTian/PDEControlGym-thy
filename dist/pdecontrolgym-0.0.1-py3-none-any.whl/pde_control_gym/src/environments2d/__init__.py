from pde_control_gym.src.environments2d.navier_stokes2D import NavierStokes2D

__all__ = ["NavierStokes2D"]
